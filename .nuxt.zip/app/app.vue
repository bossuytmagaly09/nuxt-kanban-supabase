<template>
  <NuxtLayout><!--default -->
    <NuxtPage /><!-- het slot hier worden de pages ingeladen -->
  </NuxtLayout>
</template>
